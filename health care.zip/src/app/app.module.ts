import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
//import { HealthComponent } from './../health/health.component';
import { HomeComponent } from './../home/home.component';
import { DoctorComponent } from './../doctor/doctor.component';
import {UserComponent} from './../user/user.component';
import {DoctorDetailsComponent} from './../doctor-details/doctor-details.component';
import { FormsModule} from '@angular/forms';
import {AboutComponent} from './../about-us/about-us.component'
import {ErrorComponent} from './../error/error.component';

@NgModule({
  declarations: [
    AppComponent ,HomeComponent,UserComponent,DoctorComponent,
    DoctorDetailsComponent,AboutComponent,ErrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
