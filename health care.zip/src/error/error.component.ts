import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'error-root',
  templateUrl: './error.component.html'
 
})
export class ErrorComponent {
  constructor(private route: ActivatedRoute, private router: Router) { };

  title = 'title';
  onBack(): void {

        this.router.navigate(['/home']);
    }
}
